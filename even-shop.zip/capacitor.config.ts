import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.evenshop.app',
  appName: 'EVEN SHOP',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
